﻿namespace NeedForSpeed
{
    using System;
    public class StartUp
    {
        public static void Main(string[] args)
        {
            FamilyCar race = new FamilyCar(250, 10);
            race.Drive(50);
            Console.WriteLine(race.Fuel);

        }
    }
}