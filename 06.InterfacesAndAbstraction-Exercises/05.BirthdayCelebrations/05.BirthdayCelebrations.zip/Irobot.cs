﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface Irobot : IIdentifiable
    {
  
        public string Model { get;  }
     
    }
}
