﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite
{
   public interface IMission
    {
        string CodeName { get; }
        MisionState Misionstate { get; }
        void CompleteMision();
    }
}
