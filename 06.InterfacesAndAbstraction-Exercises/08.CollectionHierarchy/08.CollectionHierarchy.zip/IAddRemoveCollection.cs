﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.CollectionHierarchy
{
   public interface IAddRemoveCollection
    {
        void Add(string add);
        string Remove(int n);
    }
}
