﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.CollectionHierarchy
{
    public interface IMyList
    {
        void Add(string add);
        string Remove(int n);

    }
}
